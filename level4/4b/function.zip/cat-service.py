import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

import sys

import boto3

def lambda_handler(event, context):
    logger.info("im in! car")
    # Work in Progress: Requires help from Agents! 
    
    ec2 = boto3.resource('ec2')

    # instances = ec2.create_instances(
    #    ImageId="???",
    #    MinCount=1,
    #    MaxCount=1,
    #    InstanceType="t2.micro"
    # )

    username = 'user-9346c006d1834264b66974b283fa5db9-bob2'
    if len(sys.argv) > 1:
        v = str(sys.argv[1])
        username = 'user-9346c006d1834264b66974b283fa5db9-bob' + v
    

    instances = ec2.create_instances(
       ImageId="ami-08569b978cc4dfa10",
       MinCount=1,
       MaxCount=1,
       InstanceType="t2.micro",
       IamInstanceProfile={
            'Arn': 'arn:aws:iam::051751498533:instance-profile/ec2_agent_instance_profile',
            'Name': 'ec2_agent_instance_profile'
       },
       TagSpecifications=[
            {
                'ResourceType': 'instance',
                'Tags': [
                    {
                        'Key': 'agent',
                        'Value': username
                    },
                ]
            },
        ],
    )

    logger.info(f"length of instances: {len(instances)}")
    my_instance = instances[0]
    d = {
        0  : "pending",
        16 : "running",
        32 : "shutting-down",
        48 : "terminated",
        64 : "stopping",
        80 : "stopped"
    }
    logger.info(my_instance.state)
    if my_instance.state in d:
        logger.info(d[my_instance.state])
    logger.info(my_instance.state_reason)
    
    logger.info("im out! wof")

    # return {
    #     'status': 200,
    #     'results': 'This is work in progress. Agents, palindrome needs your help to complete the workflow! :3'
    # }
