import boto3

import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info("im in!")

    ec2 = boto3.client('ec2')
    response = ec2.describe_instances()
    logger.info(response)

    logger.info("im out!")